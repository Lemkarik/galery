from flask import Flask, url_for, render_template, request
import os


app = Flask(__name__)


@app.route('/galery', methods=['POST', 'GET'])
def galery():
    if request.method == 'GET':
        images = []
        for directory, directories, files in os.walk('static/img'):
            images = [url_for('static', filename='img/' + i) for i in files]
        return render_template('galery.html', images=images)
    elif request.method == 'POST':
        f = request.files['file']
        map_file = 'static/img/mars1.jpg'
        for i in range(2, 1000):
            if not os.path.exists(map_file):
                break
            map_file = f'static/img/mars{i}.jpg'
        with open(map_file, 'wb') as file:
            file.write(f.read())
        return "Картинка отправлена"


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')